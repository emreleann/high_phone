export default /* glsl */`
vec3 objectNormal = vec3( normal );
`;
